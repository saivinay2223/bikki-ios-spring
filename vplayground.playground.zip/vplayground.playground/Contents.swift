import UIKit

var greeting = "Hello, playground"
print(greeting)
var welcome = "welcome to shift !😉"
print(welcome);

var name: String = "vinay"
print("hello , \(name)!");

print("hi, +name")
print("hi,"+name)

print("hi", 12, 12.99)
//print("hi"+12+12.99) //cannot concatenate with + fot different data types.
print(12+12)



//worksheet
print("ios development" , 2025, "version 17.0")

var mobileos = "ios"
print("the most popular mobile operating system is \(mobileos).")

var batterylife = 12
print("your device lasts \(batterylife) hours on average, and with optimization, it could last \(batterylife+3) hours")
print("\(batterylife+3)")
print("\(batterylife*2)")
batterylife=batterylife+2
print("\(batterylife)")

let appname : String = "chatgpt"
print(appname)

print("supporteddevices:")
print("iphone", "ipad", "apple", separator: ",")


let version = 20.0
print(version)

print(2023, 2025, 2030)
print(1.1, 2.5, 3.9)

var origin = (x :0, y:0)
var point = origin
print(point)
print("(\(origin.x),\(origin.y))")
print("(", origin.x, ",", origin.y, ")", separator: "")


let city = 60_000
print(city)
